###Verision 2.8.6 [4 DEC 2019]
* Kyma gutenberg block fontawesome icon issue fixed.
###Verision 2.8.5 [26 NOV 2019]
* Remove Google Plus social icon because Google+ no longer supported.
* Added new social media icon instagram.
###Verision 2.8.4 [21 NOV 2019]
* Fixed issue of service icon picker.
###Verision 2.8.3 [16 NOV 2019]
* New option added in customizer Home Service Layout, Home Protfolio Layout, Home Blog Layout and Calltoaction Layout.
* Manage blog post.
* Tested with latest version of WordPress.
###Verision 2.8.2 [08 NOV 2019]
* Logo issue fixed.
###Verision 2.8.1 [30 Oct 2019]
* New section added 'Breadcrumbs & Title' under General Settings tab.
###Verision 2.8.0 [23 Oct 2019]
* Page text formating issue fixed.
* Slider navigation icon color change according to theme color.
###Verision 2.7.9 [07 Oct 2019]
* Manage calendar widget.
###Verision 2.7.8 [01 Oct 2019]
* Sticky posts are highlighting.
* Css files are optimize.
###Verision 2.7.7 [27 Sep 2019]
* Manage search page.
* Minor issue fixed.
###Verision 2.7.6 [21 Sep 2019]
* Mobile menu related issue fixed.
###Verision 2.7.5 [18 Sep 2019]
* Mobile menu optimize.
* Css files optimize.
* Minor issue fixed.
###Verision 2.7.4 [09 Sep 2019]
* Minor bug fixed.
###Verision 2.7.3 [30 Aug 2019]
* Details button added on home blog when using the post excerpt option.
* Correct the slider name.
###Verision 2.7.2 [21 Aug 2019]
* Fixed issue with contact widget. Now you can remove any field if you do not want.
###Verision 2.7.1 [19 Aug 2019]
* Some improvments.
###Verision 2.7 [17 Aug 2019]
* Ajax Loading on Home Blog Section.
* Managing spacing of Home Blog section.
* Adding new option in customizer for blog section :-
	1. Enable Load More Button
	2. Load More Text
	3. Loading Text
	4. No more post Text
* Update 'Number of load more posts' option for blog section.
* Speedup home page loading time.
* Recent post widget icon not showing issue fixed.
###Verision 2.6 [17 Jan 2019]
* Gutenberg Support Added.
* Custom blocks for service, call to action and user profile added.
* FontAwesome 5.6.3 Support Added.
* Portfolio Option added.
* Woocomerce pages like shop,cart,checkout now will support right sidebar.
* Kirki plugin updated.
###Verision 2.5 [04 Oct 2018]
* Kirki package updated.
* 2 color schemes 'red' and 'orange' added.
* Navigation menu color and back to top color option added in footer section.
* Home slider comes from Page instead of Posts.
* Now you can control how many words of slider description should be shown.
* Slider readmore text option added.
* Minor improvments.
###Verision 2.4
* Child theme issue fixed.
###Verision 2.3
* Home blog post image icon URL issue fixed.
###Verision 2.2
* Compatible with WordPress 4.9
* Kirki plugin Updated.
###Verision 2.1
* Kirki plugin updated.
* Re-arranged customizer section and panel.
* Slider Title and substitle background color options added.
* Slider Sliding Effect added.
* Home services font-awesome icon picker added.
* FontAwesome latest icon pack updated.
* Theme in-built Custom CSS field will no longer work. Put all css in Additional CSS field of WordPress customizer.
###Verision 2.0.1
* Minor bug fixed.
###Verision 2.0
* Fusion Slider plugin support added(Recommended) on custom Home page.
* Removed unused code(kyma_notice.json).
* Comment issue fixed for same tag posts.
###Verision 1.9
* Remove unused tag.
* Add theme support "Custom-Header".
###Verision 1.8
* Date format issue fixed.
* HTML formating issue fixed Like: list, table etc.
* Some other minor bug fixed.
###Verision 1.7
* Minor bug fixed.
###Verision 1.6
* Unused tags removed from style.css.
* Now "load more posts" button working according to category.
* Text logo linkable issue fixed.
* Home page section reorder feature added in customizer.
* Sidebar and footer widget styling issue fixed.
* Slider text in boxed width indent properly.
* Now category, archive, tag, author posts working properly.
* Extra content section title setting added in customizer.
* Some other styling issue fixed.
###Verision 1.5
* Demo home page removed.
* Update font-awesome library.
* Update kirki customizer library.
* In extra content section content field replace by editor.
* Some minor bug fixed.
###Verision 1.4.9
* Show home blog post according category.
* Add extra content section on home page template just Go to Dashboard Admin Panel >> Appearance >> Customize >> Kyme Options >> Extra Content options >> Show Extra Content on Home.
* Kirki Customizer compatible with child-theme.
* update font-awesome library files.
* Minor bug fixed.
###Verision 1.4.8
* Comatible with WordPress.org language packs.
###Verision 1.4.7
* Top bar font color added
* Typography added
* Custom Css Field Added
* Header Section removed
* Screenshot updated
###Version 1.4.6
* Demo Home Page added.
* Header contact information issue fixed.
* Header topbar background color option added.
* Header background color option added.
* Header text color option added.
###Version 1.4.5
* Customizer saving issue solved.
###Version 1.4.4
* Some Bugs Fixed.
###Version 1.4.3
* Menu navigation issue in mobile view fixed.
###Version 1.4.2
* Page 404 error Fixed.
###Version 1.4.1
* Footer background color option added.
* RTL Support added.
###Version 1.4
* Now only using one text domain 'kyma'.
###Version 1.3
* All comments in pages is enabled.
* Remove white-spaces and proper code indent. 
* Minor issue fixed.
###Version 1.2
* Update New Customizer
* Some minor issues has been fixed
###Version 1.1
* Made some changes in readme.txt file.
* Changed text domain and filtered all files.
###Version 1.0.4
* First public release